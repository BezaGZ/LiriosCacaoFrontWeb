import { Id } from '../base.models';

/**
 * Para que se regala. Es lo que ordena la pagina /floristeria.
 *
 * Nadie busca "bouquet girasol floral": busca "algo para el cumpleanos de mi
 * mama". Por eso el catalogo de flores se entra por ocasion y no por nombre
 * de producto.
 *
 * Las que son un dia fijo del calendario llevan su fecha en OCASIONES. Esas
 * son las que mas valen: el 10 de mayo y el 14 de febrero concentran mas
 * venta que meses enteros, y sin una pagina donde aterrizar esa busqueda no
 * hay donde recibir ese trafico.
 */
export type Ocasion =
  | 'cumpleanos'
  | 'aniversario'
  | 'carino'      // 14 de febrero
  | 'madre'       // 10 de mayo
  | 'amarillas'   // 21 de septiembre
  | 'graduacion'
  | 'porque-si';

export interface OcasionInfo {
  id: Ocasion;
  etiqueta: string;
  /** Solo si la ocasion es un dia fijo del calendario. */
  fecha?: string;
}

/*
 * NO esta el Dia del Padre (17 de junio), y no es un olvido.
 *
 * Ninguno de los arreglos actuales se lee como regalo para papa: todo es
 * girasoles, rosas y fresas. Poner el filtro devolveria cero resultados, y
 * una cuadricula vacia se lee como "no tienen nada". Lo mismo con
 * condolencias: el catalogo entero es color y celebracion.
 *
 * Las dos son oportunidades de producto, no filtros que falten.
 */
export const OCASIONES: OcasionInfo[] = [
  { id: 'cumpleanos',  etiqueta: 'Cumpleaños' },
  { id: 'aniversario', etiqueta: 'Aniversario' },
  { id: 'carino',      etiqueta: 'Día del Cariño',  fecha: '14 de febrero' },
  { id: 'madre',       etiqueta: 'Día de la Madre', fecha: '10 de mayo' },
  { id: 'amarillas',   etiqueta: 'Flores amarillas', fecha: '21 de septiembre' },
  { id: 'graduacion',  etiqueta: 'Graduación' },
  { id: 'porque-si',   etiqueta: 'Solo porque sí' },
];

/**
 * Familia de producto. Separa la floristeria clasica de lo que de verdad
 * diferencia al negocio: las fresas con chocolate, que una floristeria normal
 * de Chiquimula no tiene.
 */
export type FamiliaFlor = 'flor' | 'fresas' | 'pasteleria';

export interface Flor {
  id: Id;
  nombre: string;
  slug: string;
  familia: FamiliaFlor;
  ocasiones: Ocasion[];
  descripcion: string;
  precio: number;
  imagenUrl: string;
  incluye: string[];
  personalizaciones: string[];
  notas?: string[];
  /** true mientras falten foto o precio reales: no se muestra al publico. */
  borrador?: boolean;
}

export interface CatalogoFlores {
  flores: Flor[];
}
